# Geiger ESP32 · SBM-20 · RadSens

Projektový handover pre snímač s trubicou SBM-20, XIAO ESP32-S3 a nosnou doskou MultiGeiger Rev. C. XIAO má poskytovať telemetriu po I²C na adrese `0x66`. Hostiteľom je Heltec T096 s Meshtasticom.

## Stav k 12. novembru 2026

- Zdrojový ovládač Meshtasticu číta tri bajty od registra `0x06`. Prvým cieľom je zobraziť na T096 kontrolnú hodnotu `6.0` pri odpovedi `00 00 3C`.
- Balík obsahuje návrh firmvéru, protokol, skúšobný postup, podklady na nacenenie a spustiteľný model protokolu. Na nahratie do XIAO ešte treba doplniť a otestovať ovládač ESP-IDF.
- Verejný repozitár je pripravený na založenie. Pracovný názov `imarkone/geiger-esp32-radsens` bol pri kontrole nedostupný cez API (404). GitHub zobrazil prihlásenému účtu formulár pre nový verejný repozitár.
- Pre Rev. C je pracovná voľba zverejnená V2 s obyčajným XIAO ESP32-S3. Mechaniku SBM-20 a rozsah osadenia musí potvrdiť ponuka a skúška.

## Pokračovanie

1. Prečítať [technický handover](docs/HANDOVER.md) a [kontrakt I²C](docs/PROTOCOL.md).
2. Spustiť `node --test` v koreňovom priečinku (Node.js 22+). Model a testy slúžia ako referenčné správanie pre port do C.
3. Postaviť skúšku `bench-i2c` na samostatnom XIAO a prejsť etapy A a B v [testovacom pláne](docs/VALIDATION.md).
4. Súbežne pripraviť cenu Rev. C podľa [výrobného listu](docs/PCB.md). Po doručení urobiť etapy C a D.

## Zverejnenie

Na [GitHub New](https://github.com/new) vytvoriť verejný repozitár pod vybraným účtom. Pri publikovaní z lokálneho Gitu ponechať nový repozitár prázdny a spustiť z koreňa rozbaleného balíka:

```sh
git init -b main
git add README.md docs reference
git commit -m "Add SBM-20 RadSens project handover"
git remote add origin https://github.com/imarkone/geiger-esp32-radsens.git
git push -u origin main
```

Príkaz push vyžaduje prihlásený Git s oprávnením na zápis. Alternatíva pre konektor je inicializovať repozitár cez GitHub s README, udeliť existujúcej GitHub aplikácii prístup k tomuto repozitáru a pridať súbory cez Contents API. Konektor v tejto relácii ponúkal zápis súborov a commitov v existujúcom repozitári. Licenciu pre vlastný kód má zvoliť vlastník pred jeho ďalším využitím tretími stranami. Podmienky prevzatia cudzieho kódu sú v handoveri.
